
#include <iostream>
#include <vector>
#include <string>
#include <queue>
#include <stack>
#include <unordered_set>
#include "board.hpp"

using namespace std;

class Node
{
public:
    Board *board;
    int g;
    int h;
    Node *parent;

    Node(Board *board, int g, string heuristicType, Node *parent = NULL)
    {
        this->board = board;
        this->g = g;
        this->parent = parent;
        if (heuristicType == "hamming")
            this->h = board->hamming();
        else if (heuristicType == "manhattan")
            this->h = board->manhattan();
        else if (heuristicType == "linearConflict")
            this->h = board->linearConflict();
        else if (heuristicType == "euclidean")
            this->h = board->euclidean();
        else
        {
            cout << "Invalid heuristic type!" << endl;
            exit(1);
        }
    }

    int getF()
    {
        return g + h;
    }

    ~Node()
    {
        delete board;
    }
};

class Solver
{
private:
    unordered_set<string> closedList;
    vector<Node *> allNodes;

    stack<Board *> path;
    Node *goalNode = NULL;

    int expanded = 0;
    int explored = 0;

public:
    Solver() {}

    ~Solver()
    {
        for (auto node : allNodes)
        {
            delete node;
        }
    }

    bool isClosed(Board *b)
    {
        string str = b->boardToString();
        if (closedList.count(str))
            return true;
        closedList.insert(str);
        return false;
    }

    void solve(Board *startBoard, string heuristicType)
    {
        if (!startBoard->checkIfSolvable())
        {
            cout << "Unsolvable puzzle!" << endl;
            return;
        }

        priority_queue<pair<int, Node *>, vector<pair<int, Node *>>, greater<pair<int, Node *>>> openList;

        Node *startNode = new Node(startBoard, 0, heuristicType);
        openList.push({startNode->getF(), startNode});

        allNodes.push_back(startNode);

        // int expanded = 0, explored = 0;

        while (!openList.empty())
        {
            Node *current = openList.top().second;

            openList.pop();
            expanded++;

            if (current->board->isGoal())
            {
                goalNode = current;
                break;
            }

            vector<Board *> neighbors = current->board->allReachableBoards();
            for (auto neighbor : neighbors)
            {
                if (!isClosed(neighbor))
                {
                    Node *child = new Node(neighbor, current->g + 1, heuristicType, current);
                    openList.push({child->getF(), child});
                    explored++;
                    allNodes.push_back(child);
                }
            }
        }

        // stack<Board *> path;

        while (goalNode != NULL)
        {
            path.push(goalNode->board);
            goalNode = goalNode->parent;
        }

        // explored = closedList.size();
        closedList.clear();

        cout << "Minimum number of moves by " << heuristicType << ": " << path.size() - 1 << endl;
        cout << "Total number of Explored nodes: " << explored << endl;
        cout << "Total number of Expanded nodes: " << expanded << endl;
        cout << "Steps:" << endl;
        while (!path.empty())
        {
            path.top()->printBoard();
            path.pop();
        }
    }
};

int main()
{
    cout << "Enter the size of the board (k x k): ";
    int k;
    cin >> k;
    cout << "Enter the board configuration (0 for blank):" << endl;
    vector<vector<int>> input(k, vector<int>(k));
    for (int i = 0; i < k; i++)
    {
        for (int j = 0; j < k; j++)
        {
            cin >> input[i][j];
        }
    }

    Board *start = new Board(k, input);
    Solver solver;

    cout << "Select heuristic:" << endl;
    cout << "1. Hamming" << endl;
    cout << "2. Manhattan" << endl;
    cout << "3. Linear Conflict" << endl;
    cout << "4. Euclidean" << endl;
    cout << "5. All" << endl;
    int choice;
    cin >> choice;
    switch (choice)
    {
    case 1:
        solver.solve(start, "hamming");
        break;
    case 2:
        solver.solve(start, "manhattan");
        break;
    case 3:
        solver.solve(start, "linearConflict");
        break;
    case 4:
        solver.solve(start, "euclidean");
        break;
    case 5:
        solver.solve(start, "hamming");
        solver.solve(start, "manhattan");
        solver.solve(start, "linearConflict");
        solver.solve(start, "euclidean");
        break;
    default:
        cout << "Invalid choice!" << endl;
        break;
    }

    delete start;
    return 0;
}

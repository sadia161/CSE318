#ifndef BOARD_HPP
#define BOARD_HPP

#include <iostream>
#include <vector>
#include <cmath>
#include <string>
#include <sstream>
#include <algorithm>

using namespace std;

class Board
{
    int k;
    vector<vector<int>> board;
    pair<int, int> blankPos;

public:
    Board(int k, vector<vector<int>> board)
    {
        this->k = k;
        this->board = board;

        for (int i = 0; i < k; i++)
        {
            for (int j = 0; j < k; j++)
            {
                if (board[i][j] == 0)
                {
                    blankPos = {i, j};
                    break;
                }
            }
        }
    }

    vector<vector<int>> getBoard()
    {
        return board;
    }

    void printBoard()
    {
        for (int i = 0; i < k; i++)
        {
            for (int j = 0; j < k; j++)
            {
                cout << board[i][j] << " ";
            }
            cout << endl;
        }
        cout << "-----" << endl;
    }

    pair<int, int> findBlankPos()
    {
        return blankPos;
    }

    string toString()
    {
        stringstream ss;
        for (int i = 0; i < k; i++)
        {
            for (int j = 0; j < k; j++)
            {
                ss << board[i][j] << ",";
            }
        }
        return ss.str();
    }

    bool isGoal()
    {
        int val = 1;
        for (int i = 0; i < k; i++)
        {
            for (int j = 0; j < k; j++)
            {
                if (i == k - 1 && j == k - 1)
                {
                    if (board[i][j] != 0)
                        return false;
                }
                else
                {
                    if (board[i][j] != val)
                        return false;
                }
                val++;
            }
        }
        return true;
    }

    int manhattan()
    {
        int dist = 0;
        for (int i = 0; i < k; i++)
        {
            for (int j = 0; j < k; j++)
            {
                int val = board[i][j];
                if (val != 0)
                {
                    int targetRow = (val - 1) / k;
                    int targetCol = (val - 1) % k;
                    dist += abs(i - targetRow) + abs(j - targetCol);
                }
            }
        }
        return dist;
    }

    int linearConflict()
    {
        int conflicts = 0;

        for (int i = 0; i < k; i++) // Row conflicts
        {
            for (int j = 0; j < k; j++)
            {
                int val1 = board[i][j];
                if (val1 == 0)
                    continue;
                int goalRow1 = (val1 - 1) / k;
                if (goalRow1 == i)
                {
                    for (int j2 = j + 1; j2 < k; j2++)
                    {
                        int val2 = board[i][j2];
                        if (val2 == 0)
                            continue;
                        int goalRow2 = (val2 - 1) / k;
                        if (goalRow2 == i && val1 > val2)
                        {
                            conflicts++;
                        }
                    }
                }
            }
        }

        // Column conflicts
        for (int j = 0; j < k; j++)
        {
            for (int i = 0; i < k; i++)
            {
                int val1 = board[i][j];
                if (val1 == 0)
                    continue;
                int goalCol1 = (val1 - 1) % k;
                if (goalCol1 == j)
                {
                    for (int i2 = i + 1; i2 < k; i2++)
                    {
                        int val2 = board[i2][j];
                        if (val2 == 0)
                            continue;
                        int goalCol2 = (val2 - 1) % k;
                        if (goalCol2 == j && val1 > val2)
                        {
                            conflicts++;
                        }
                    }
                }
            }
        }

        return manhattan() + 2 * conflicts;
    }

    int hamming()
    {
        int count = 1;
        int wrong = 0;
        for (int i = 0; i < k; i++)
        {
            for (int j = 0; j < k; j++)
            {
                if (board[i][j] != 0 && board[i][j] != count)
                    wrong++;
                count++;
            }
        }
        return wrong;
    }

    double euclidean()
    {
        double dist = 0;
        for (int i = 0; i < k; i++)
        {
            for (int j = 0; j < k; j++)
            {
                int val = board[i][j];
                if (val != 0)
                {
                    int targetRow = (val - 1) / k;
                    int targetCol = (val - 1) % k;
                    dist += sqrt((i - targetRow) * (i - targetRow) + (j - targetCol) * (j - targetCol));
                }
            }
        }
        return dist;
    }

    vector<int> flattenBoard()
    {
        vector<int> flat;
        for (int i = 0; i < k; i++)
        {
            for (int j = 0; j < k; j++)
            {
                flat.push_back(board[i][j]);
            }
        }
        return flat;
    }

    int countInversions()
    {
        vector<int> flat = flattenBoard();
        int inv = 0;
        for (int i = 0; i < flat.size(); i++)
        {
            for (int j = i + 1; j < flat.size(); j++)
            {
                if (flat[i] != 0 && flat[j] != 0 && flat[i] > flat[j])
                    inv++;
            }
        }
        return inv;
    }

    int blankRowFromBottom()
    {
        return k - blankPos.first;
    }

    bool checkIfSolvable()
    {
        int inv = countInversions();

        if (k % 2 == 1)
        {
            return inv % 2 == 0;
        }
        else
        {
            int blankRow = blankRowFromBottom();
            return (blankRow % 2 == 0) != (inv % 2 == 0);
        }
    }

    vector<Board *> allReachableBoards()
    {
        vector<Board *> neighbors;
        int dx[] = {-1, 1, 0, 0};
        int dy[] = {0, 0, -1, 1};

        for (int d = 0; d < 4; d++)
        {
            int ni = blankPos.first + dx[d];
            int nj = blankPos.second + dy[d];

            if (ni >= 0 && ni < k && nj >= 0 && nj < k)
            {
                vector<vector<int>> newBoard = board;

                swap(newBoard[blankPos.first][blankPos.second], newBoard[ni][nj]); // Swap the blank with the adjacent tile
                Board *b = new Board(k, newBoard);
                neighbors.push_back(b);
            }
        }

        return neighbors;
    }

    string boardToString()
    {
        string s = "";
        for (int i = 0; i < k; i++)
        {
            for (int j = 0; j < k; j++)
            {
                s += to_string(board[i][j]) + ",";
            }
        }
        return s;
    }

    bool isSame(vector<vector<int>> &otherBoard)
    {
        for (int i = 0; i < k; i++)
        {
            for (int j = 0; j < k; j++)
            {
                if (board[i][j] != otherBoard[i][j])
                    return false;
            }
        }
        return true;
    }
};

#endif